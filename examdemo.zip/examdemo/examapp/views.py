from django.shortcuts import render,redirect
from .models import * ;
# Create your views here.
def home(request):
    return render(request,'home.html')

def dashboard(request):
    return render(request,'dashboard.html')
    
def student(request):
        return render(request,'Stu.html')

def login(request):
    if request.method=='POST':
        A = request.POST.get("email")
        B = request.POST.get("password")
        if A=="student@gmail.com" and B=="12345":
            return render(request,'stu-dash.html')
        else:
            return render(request,'Stu.html')

def teacher(request):
    return render(request,'Tea.html')

def login1(request):
    if request.method=='POST':
        A = request.POST.get("email")
        B = request.POST.get("password")
        if A=="teacher@gmail.com" and B=="12345":
            return render(request,'tea-dash.html')
        else:
            return render(request,'Tea.html')

def admin(request):
    return render(request,'Admin.html')

def login2(request):
    if request.method=='POST':
        A = request.POST.get("email")
        B = request.POST.get("password")
        if A=="Admin@gmail.com" and B=="12345":
            return render(request,'adm-dash.html')
        else:
            return render(request,'Admin.html')

def regstu(request):
    return render(request,'regstu.html')

def insertStu(request):
    if request.method=='POST':
        name=request.POST.get("name")
        email=request.POST.get("email")
        password=request.POST.get("pass")
        phone = request.POST.get("phone")
     
        e=Student()
        e.name=name
        e.email=email
        e.Password= password
        e.Phone= phone
        e.save()
        return redirect('/')
    else:
        return render(request,'regstu.html')

def regtea(request):
    return render(request,'regtea.html')

def insertTea(request):
    if request.method=='POST':
            name=request.POST.get("name")
            email=request.POST.get("email")
            password=request.POST.get("pass")
            phone = request.POST.get("phone")
        
            e=Teacher()
            e.name=name
            e.email=email
            e.password= password
            e.phone= phone
            e.save()
            return redirect('/')
    else:
        return render(request,'regtea.html')

def regadmin(request):
    return render(request,'regadmin.html')

def insertAdm(request):
    if request.method=='POST':
            name=request.POST.get("name")
            email=request.POST.get("email")
            password=request.POST.get("pass")
            phone = request.POST.get("phone")
        
            e=Admin()
            e.name=name
            e.email=email
            e.password= password
            e.phone= phone
            e.save()
            return redirect('/')
    else:
        return render(request,'regadmin.html')
