from django.contrib import admin
from django.urls import path
from .import views as v

urlpatterns = [
    path('admin/', admin.site.urls),
   
    path('dashboard',v.dashboard),
    path('',v.home),
    path('student',v.student),
    path('teacher',v.teacher),
    path('admin',v.admin),
    path('regstu',v.regstu),
    path('regtea',v.regtea),
    path('regadmin',v.regadmin),
    path('login',v.login),
    path('login1',v.login1),
    path('login2',v.login2),
    path('instu',v.insertStu),
    path('intea',v.insertTea),
    path('inadmin',v.insertAdm)

]